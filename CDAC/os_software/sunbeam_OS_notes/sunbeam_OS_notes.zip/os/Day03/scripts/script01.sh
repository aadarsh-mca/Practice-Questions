#!/bin/bash

# This is comment

# Shebang line
#	indicates for which shell this script is written

echo "Today's date : "
date

echo "Current month calender : "
cal

echo "Present working directory : "
pwd

echo "Operating system : "
uname











