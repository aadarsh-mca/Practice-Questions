#!/bin/bash

#	Variable declaration
#		varName=value

#	Use variable value
#		$varName

num=10
pi=3.142
name=sunbeam

echo $num
echo $pi
echo $name

echo "num = $num"
echo "pi = $pi"
echo "name = $name"











