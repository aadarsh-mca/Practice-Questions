#include"Product.h"

int main()
{
	Date mfgDate(12, 3, 2024);
	Product p1("Tv", 56000,mfgDate);
	p1.display();

	cout << "\n P2-------------";
	Product p2;
	p2.display();
}