#pragma once

#include<iostream>
using namespace std;
#include<string>
#include"Date.h"
class Product
{
private:
	int pid;  //auto gen
	string pname; 
	float price;
	Date mfgDate;
	static int count;
public:
	Product();
	Product(string pname, float price,
		Date& mfgDate);
	void accept();
	void display();
	string getPname();
	float getPrice();
	void setPname(string pname);
	void setPrice(float price);
	
};
