#include"Order.h"

int main()
{
	int nop;
	cout << "\n enter the number of products:";
	cin >> nop;
	Order o1(nop);
	o1.accept();
	o1.display();
	o1.calOrderTotal();
	{
		Order o2 = o1; //Order o2(o1);
		//copy constructor- 
		// initialize a current object based on another object val
		cout << "\n O2-----------------------";
		o2.display();
		o2.calOrderTotal();
	}

	return 0;
}