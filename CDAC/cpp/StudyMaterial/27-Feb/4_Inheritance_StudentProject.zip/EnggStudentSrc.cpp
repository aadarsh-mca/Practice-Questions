#include"EnggStudent.h"

EnggStudent::EnggStudent()
{
	projectGrade = 'N';
}

EnggStudent::EnggStudent(string name, float marks, char projectGrade)
	:Student(name,marks)
{
	this->projectGrade = projectGrade;
}

void EnggStudent::accept()
{
	Student::accept();
	cout << "\n enter project grade:";
	cin >> projectGrade;
}

void EnggStudent::display()
{
	Student::display();
	cout << "\n project grade:" << projectGrade;
}