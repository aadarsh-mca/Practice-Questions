#pragma once
#include"Student.h"

class EnggStudent:public Student
{
private:
	char projectGrade;
public:
	EnggStudent();
	EnggStudent(string name, float marks, char projectGrade);

	void accept();
	void display();

};
