#include"Student.h"

int Student::count = 0;
Student::Student()
{
	count++;
	id = count;
	name = "NA";
	marks = 0.0f;
}

Student::Student(string name, float marks)
{
	count++;
	id = count;
	this->name = name;
	this->marks = marks;
}

void Student::accept()
{
	cout << "\n Enter the name:";
	cin >> name;
	cout << "\n enter the marks:";
	cin >> marks;
}

void Student::display()
{
	cout << "\n the id " << id << " name " << name << " marks " << marks;
}