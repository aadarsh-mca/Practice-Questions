#include"EnggStudent.h"

int main()
{
	EnggStudent e1; //base default->derived default
	e1.display();


	EnggStudent e2("king", 78, 'A');
	e2.display();
	
}