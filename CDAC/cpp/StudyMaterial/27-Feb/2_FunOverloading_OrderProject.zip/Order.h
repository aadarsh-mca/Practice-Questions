#pragma once
#include<iostream>
using namespace std;

class Order
{
private:
	int nop;
	float* price;
public:
	Order(int nop);
	Order(Order&o);
	void accept();
	void display();
	void calOrderTotal();
	void calOrderTotal(string couponcode);
	void calOrderTotal(string couponcode, bool membership);
	~Order();
};
