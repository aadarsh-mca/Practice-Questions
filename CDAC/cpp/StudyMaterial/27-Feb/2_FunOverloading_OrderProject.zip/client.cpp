#include"Order.h"

int main()
{
	int nop;
	cout << "\n enter the number of products:";
	cin >> nop;
	Order o1(nop);
	o1.accept();
	o1.display();
	o1.calOrderTotal();
	o1.calOrderTotal("ABC");
	o1.calOrderTotal("ABC", true);

	return 0;
}