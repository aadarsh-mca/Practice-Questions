#include"Order.h"

Order::Order(int nop)
{
	this->nop = nop;
	this->price = new float[this->nop];
	for (int i = 0; i < this->nop; i++)
	{
		this->price[i] = 0;
	}
}

Order::Order(Order& o)
{
	this->nop = o.nop;
	this->price = new float[this->nop];
	for (int i = 0; i < this->nop; i++)
	{
		this->price[i] = o.price[i];
	}
}

void Order::accept()
{
	for (int i = 0; i < this->nop; i++)
	{
		cout << "\n enter the price:";
		cin >> price[i];
	}
}

void Order::display()
{
	for (int i = 0; i < this->nop; i++)
	{
		cout << "\n the price is " << price[i];
	}
}

void Order::calOrderTotal()
{
	float sum = 0;
	for (int i = 0; i < this->nop; i++)
	{
		sum = sum + price[i];
	}
	cout << "\n your order total is " << sum;
}

Order::~Order()
{
	if (price != NULL)
	{
		delete[] price;
		price = NULL;
	}
}

void Order::calOrderTotal(string couponcode)
{
	float sum = 0;
	for (int i = 0; i < this->nop; i++)
	{
		sum = sum + price[i];
	}
	if (couponcode == "ABC")
	{
		sum = sum - 100;
	}
	cout << "\n the order total is " << sum;
}
void Order::calOrderTotal(string couponcode, bool membership)
{
	float sum = 0;
	for (int i = 0; i < this->nop; i++)
	{
		sum = sum + price[i];
	}
	if (couponcode == "ABC")
	{
		sum = sum - 100;
	}
	if (membership == true)
	{
		sum = sum - 50;
	}
	cout << "\n the order total is " << sum;
}