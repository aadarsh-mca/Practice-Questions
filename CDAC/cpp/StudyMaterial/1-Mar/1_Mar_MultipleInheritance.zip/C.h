#pragma once
#include"A.h"
#include"B.h"
class C :public A, public B
{

public:
	void print()
	{
		cout << "\n in the print() of class C";
	}
	void show()
	{
		cout << "\n in show() of C";
	}
};
