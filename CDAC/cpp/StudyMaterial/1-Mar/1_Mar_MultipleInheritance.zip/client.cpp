#include"C.h"

int main()
{
	C obj;
	obj.show();  //in c
	obj.A::show();  //A
	obj.B::show();  //B
	obj.print();  //C
}