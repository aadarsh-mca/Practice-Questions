#pragma once
#include<iostream>
using namespace std;

class A
{
public:
	void show()
	{
		cout << "\n In A";
	}
};
