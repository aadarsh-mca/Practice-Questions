#pragma once
#include<iostream>
using namespace std;

class B
{
public:
	void show()
	{
		cout << "\n In B";
	}
};
