#include"Complex.h"

int main()
{
	Complex c1(3, 1);
	cout << "\n c1--------------";
	c1.display();

	Complex c4(0, 0);
	c4 = -c1;  //  c4=c1.operator-();
	c4.display();

	//Complex c2(6, 2);
	//cout << "\n c1--------------";
	//c2.display();

	//Complex c3(0, 0);
	//c3 =c1+c2;  //c3=c1.operator+(c2)
	//c3.display();

}