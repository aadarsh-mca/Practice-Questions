#include"Complex.h"

Complex::Complex(float real, float imag)
{
	this->real = real;
	this->imag = imag;
}

void Complex::display()
{
	cout << "\n the complex number is :" << real << "+" << imag << "i";
}

Complex& Complex::operator+(Complex& cref)
{
	Complex temp(0,0);
	temp.real = this->real + cref.real;
	temp.imag = this->imag + cref.imag;
	return temp;
}
Complex& Complex:: operator-()
{
	Complex temp(0, 0);
	temp.real = -this->real;
	temp.imag = -this->imag;
	return temp;
}