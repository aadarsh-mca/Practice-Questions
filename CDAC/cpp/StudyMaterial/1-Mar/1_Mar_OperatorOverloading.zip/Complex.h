#pragma once
#include<iostream>
using namespace std;

class Complex
{
private:
	float real, imag;
public:
	Complex(float real, float imag);
	void display();
	Complex& operator+(Complex& cref);
	Complex& operator-();
};
