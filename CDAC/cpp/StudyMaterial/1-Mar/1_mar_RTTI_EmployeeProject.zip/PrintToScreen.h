#include<iostream>
using namespace std;
#include"Employee.h"
#include"SalesPerson.h"
#include"Manager.h"
class PrintToScreen
{
public:
	//display the details of an employee recevied in para
	static void displayEmployeeDetails(Employee * emp)
	{
		emp->display();
		//if emp is SalesPerson then display
		//Bonus 10000
		//rtti - runtime type identification

		if (typeid(*emp) == typeid(SalesPerson))
		{
			SalesPerson* sp = dynamic_cast<SalesPerson*>(emp);
			sp->payBonus();
		}
		if (typeid(*emp) == typeid(Manager))
		{
			Manager* m = dynamic_cast<Manager*>(emp);
			m->payPerformancePerks();
		}
	}

	static void displayEmployeeDetails(Employee& emp)
	{
		emp.display();

		//if emp is SalesPerson then display
		//Bonus 10000
		//rtti - runtime type identification

		if (typeid(emp) == typeid(SalesPerson))
		{
			SalesPerson& sp = dynamic_cast<SalesPerson&>(emp);
			sp.payBonus();
		}
		if (typeid(emp) == typeid(Manager))
		{
			Manager& m = dynamic_cast<Manager&>(emp);
			m.payPerformancePerks();
		}


	}
};