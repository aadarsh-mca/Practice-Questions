#pragma once
#include<iostream>
using namespace std;
#include"D.h"
class B:virtual public D
{
public:
	void show()
	{
		cout << "\n In B";
	}
};
