#include"C.h"

int main()
{
	C obj;
	obj.A::fun();
	
}