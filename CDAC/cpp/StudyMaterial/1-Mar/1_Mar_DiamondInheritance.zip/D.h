#pragma once
#include<iostream>
using namespace std;

class D
{
private:
	int x;
public:
	D()
	{
		x = 10;
	}

	void fun()
	{
		cout << "\n the value of x is " << x;
	}
};
