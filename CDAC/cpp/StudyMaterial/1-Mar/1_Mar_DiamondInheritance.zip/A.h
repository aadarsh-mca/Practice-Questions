#pragma once
#include<iostream>
using namespace std;
#include"D.h"

class A:virtual public D
{
public:
	void show()
	{
		cout << "\n In A";
	}
};
