#pragma once

#include"Circle.h"
#include"Square.h"

class PrintToScreen
{
public:
	static void displayArea(Shape& _shape)
	{
		cout << "\n the area is " << _shape.calArea();
		if (typeid(_shape) == typeid(Circle))
		{
			Circle& _circle = dynamic_cast<Circle&>(_shape);
			cout<<"\n the circumference is "<<_circle.calCircumference();
		}
	}
	static void displayArea(Shape* _shape)
	{
		cout << "\n the area is " << _shape->calArea();
		if (typeid(*_shape) == typeid(Circle))
		{
			Circle* _circle = dynamic_cast<Circle*>(_shape);
			cout << "\n the circumference is " << _circle->calCircumference();
		}
	}
};
