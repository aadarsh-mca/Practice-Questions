#pragma once
#include"Shape.h"

class Circle :public Shape
{
private:
	float radius;
public:
	Circle(float radius)
	{
		this->radius = radius;
	}
	float calArea()
	{
		area = 3.14f * radius * radius;
		return area;
	}
	float calCircumference()
	{
		return 2 * 3.14f * radius;
	}
};
