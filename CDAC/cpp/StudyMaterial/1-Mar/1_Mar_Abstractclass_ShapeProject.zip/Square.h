#pragma once
#include"Shape.h"

class Square :public Shape
{
private:
	float side;
public:
	Square(float side)
	{
		this->side = side;
	}
	float calArea()
	{
		area = side*side;
		return area;
	}
};
