#pragma once
#include<iostream>
using namespace std;

class Shape
{
protected:
	float area;
public:
	Shape()
	{
		area = 0.0f;
	}
	virtual float calArea() = 0;
	void print()
	{
		cout << "\n in Shape class";
	}
};
