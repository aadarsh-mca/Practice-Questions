#include"Square.h"
#include"Circle.h"
#include"PrintToScreen.h"
int main()
{
	Circle c1(3.2f);
	PrintToScreen::displayArea(c1);

	Square s1(5.6);
	PrintToScreen::displayArea(s1);

}