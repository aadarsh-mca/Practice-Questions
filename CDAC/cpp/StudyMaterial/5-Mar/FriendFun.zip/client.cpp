#include"Demo.h"

int main() {
    Demo obj(10);
    showValue(obj); // Friend function accessing private member
    return 0;
}
