#pragma once
#include <iostream>
using namespace std;


class Demo {
private:
    int value;

public:
    Demo(int v) {
        value = v;
    }

    // Declare friend function
   friend void showValue(Demo d);
};

// Friend function definition
void showValue(Demo d) {
    cout << "Value: " << d.value << endl;
}
