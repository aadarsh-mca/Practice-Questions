#include <iostream>
#include <iomanip>  // Required for formatting
using namespace std;

int main() {
    double num = 123.456;
    string str = "HelloWorld";

    // Formatted output
    cout << "Formatted Output:\n";
    cout << "Fixed: " << fixed << setprecision(2) << num << endl;
    cout << "Scientific: " << scientific << num << endl;
    cout << "Width 15: "<<std::left<< setw(15) <<setfill('*')<< str << endl;
    cout <<fixed<< num;

    return 0;
}
