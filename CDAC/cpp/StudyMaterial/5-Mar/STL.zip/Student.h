#include<iostream>
using namespace std;

class Student
{
	int id;
	string name;
	float marks;
public:
	Student()
	{
		id = 0;
		name = "NA";
		marks = 0.0f;
	}
	void accept()
	{
		cout << "\n enter the details:";
		cin >> id >> name >> marks;
	}
	void display()
	{
		cout << "\n the details are------";
		cout << id << endl;
		cout << name << endl;
		cout << marks << endl;
	}
};