#include <iostream>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <algorithm>

using namespace std;
#include"Student.h"

int main() {

    // 1. Vector Demo (Dynamic Array)
    //vector<int> numbers = { 10, 20, 30, 40, 50 };
    //cout << numbers[2];
    //numbers.push_back(60);  // Add element at the end
    //cout << "Vector Elements: ";
    //for (int num : numbers)
    //{
    //    cout << num << " ";
    //}
    //cout << endl;

    //vector<Student> students;
    //string wish;

    //do
    //{
    //    Student obj;
    //    obj.accept();
    //    students.push_back(obj);
    //    cout << "\n do u wish to continue:";
    //    cin >> wish;
    //} while (wish == "yes");

    //for (Student s : students)
    //{
    //    s.display();
    //}

    // 2. List Demo (Doubly Linked List)
    //list<string> names = { "Alice", "Bob", "Charlie" };
    //names.push_front("Zara");  // Insert at the beginning
    //cout << "List Elements: ";
    //for (const string& name : names)
    //{
    //    cout << name << " ";
    //}
    //cout << endl;


    // 3. Set Demo (Unique Sorted Elements)
    //set<int> uniqueNumbers = { 50, 10, 30, 20, 40 };
    //uniqueNumbers.insert(20);  // Duplicate won't be added
    //cout << "Set Elements: ";
    //for (int num : uniqueNumbers)
    //{
    //    cout << num << " ";
    //}
    //cout << endl;

    // 4. Map Demo (Key-Value Pair)
    /*map<int, string> studentMap;
    int id;
    string name;
    studentMap[101] = "Alice";
    studentMap[102] = "Bob";
    studentMap[103] = "Charlie";
    cout << "Map Elements:\n";
    for (auto obj: studentMap)
        cout << "ID: " << obj.first << ", Name: " << obj.second << endl;*/


    // 5. Algorithm Demo
    vector<int> nums = { 5, 3, 8, 1, 9 };
    sort(nums.rbegin(), nums.rend()); // Sort the vector
    cout << "Sorted Vector: ";
    for (int num : nums) cout << num << " ";
    cout << endl;

    // Find an element
    auto it = find(nums.begin(), nums.end(), 8);
    if (it != nums.end())
        cout << "Element 8 found at index: " << distance(nums.begin(), it) << endl;
    else
        cout << "Element 8 not found." << endl;



    return 0;
}
