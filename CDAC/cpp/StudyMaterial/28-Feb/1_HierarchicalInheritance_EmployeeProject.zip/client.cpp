#include"Manager.h"
#include"SalesPerson.h"


//version1- demo of compile time binding/hierarchical inheritance
int main()
{
	Manager m1;
	//employee default->manager default constr
	cout << "\n default of manager----------";
	m1.display();
	cout << "\n no of object is " << Employee::getCount() - 100;

	Date doj1(12, 3, 2021);
	Manager m2("King", 45000, doj1, 10000, 4000);
	//employee para->Manager para constr
	cout << "\n para of manager----------";
	m2.display();
	cout << "\n no of object is " << Employee::getCount()-100;

	SalesPerson sp1;  //Employee def->SalesPerson def
	cout << "\n def of Salesperson----------";
	sp1.display();  
	cout << "\n no of object is " << Employee::getCount()-100;

	Date doj2(4, 3, 2023);
	SalesPerson sp2("Ernst", 78000, doj2, 1000, 0.10);
	cout << "\n para of Salesperson----------";
	sp2.display();
	cout << "\n no of object is " << Employee::getCount() - 100;
}