#include"MathEngine.h"

int main()
{
	cout << "\n the max of 2 int is " << MathEngine::CalMax(12, 78);
	cout << "\n the max of 2 double is " << MathEngine::CalMax(12.5, 7.8);
	cout << "\n the max of 2 strings is " << MathEngine::CalMax("Hello", "World");

	int n1 = 10, n2 = 20;
	cout << "\n before swappin n1-" << n1 << " n2-" << n2;
	MathEngine::swapValues(n1, n2);
	cout << "\n after swappin n1-" << n1 << " n2-" << n2;

	string s1 = "Hello", s2 = "world";
	cout << "\n before swappin s1-" << s1 << " s2-" << s2;
	MathEngine::swapValues(s1, s2);
	cout << "\n after swappin s1-" << s1 << " s2-" << s2;

}