#pragma once
#include<iostream>
using namespace std;

class MathEngine
{
public:
	template <typename T>
	static T CalMax(T n1, T n2)
	{
		return (n1 > n2) ? n1: n2;
	}

	template <typename T>
	static void swapValues(T& n1, T& n2)
	{
		T temp;
		temp = n1;
		n1 = n2;
		n2 = temp;
	}

};