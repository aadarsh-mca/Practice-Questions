#pragma once
#include<iostream>
using namespace std;

class PrintToScreen
{
public:
	template<typename T1,typename T2>
	static void show(T1 n1, T2 n2)
	{
		cout << "\n the value of n1 is " << n1;
		cout << "\n the value of n2 is " << n2;
	}
};
