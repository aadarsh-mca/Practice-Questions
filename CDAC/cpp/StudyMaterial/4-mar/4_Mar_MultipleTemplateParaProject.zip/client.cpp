#include"PrintToScreen.h"

int main()
{
	PrintToScreen::show(12, 17);
	PrintToScreen::show("hello", 1.7);
}