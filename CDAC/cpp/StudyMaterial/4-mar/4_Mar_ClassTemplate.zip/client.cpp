#include"Box.h"

int main() {
    Box<int> intBox(100);
    Box<double> doubleBox(45.67);
    Box<string> stringBox("Hello Templates");

    intBox.show();
    doubleBox.show();
    stringBox.show();

    return 0;
}
