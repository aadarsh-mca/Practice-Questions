#pragma once
#include <iostream>
using namespace std;

template <typename T>
class Box {
private:
    T value;
public:
    Box(T v)  // Constructor
    { 
        value = v; 
    } 
    void show() { cout << "Stored Value: " << value << endl; }
};
