//accept an array of 5 int and display

#include<iostream>
using namespace std;

int main()
{
	int arr[5];

	for (int i = 0; i < 5; i++)
	{
		cout << "\n ENter the ele:";
		cin >> arr[i]; // task- try using pointer notation
	}
	for (int i = 0; i < 5; i++)
	{
		cout << arr[i] << endl;
	}
	return 0;
}