//write a function to check whether a user entered number is
//even or odd, print the result in main

#include<iostream>
using namespace std;

bool check(int);

int main()
{
	int num;
	bool flag;

	cout << "\n Enter the num:";
	cin >> num;

	flag = check(num);
	(flag == true) ? cout << "\n EVEN" : cout << "\n ODD";
	return 0;
}

bool check(int num)
{
	if (num % 2 == 0)
	{
		return true;
	}
	return false;
}
