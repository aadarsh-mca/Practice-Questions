//write a program for accepting a number in main and calculate the
//sum of digits in a seperate funtion  and display result in main
#include<iostream>
using namespace std;

int calculate(int);
int main()
{
	int num, sum;
	cout << "\n Enter the num:";
	cin >> num;
	sum = calculate(num);
	cout << "\n the sum is " << sum;
	return 0;
}
int calculate(int num)
{
	int dig, sum = 0;
	while (num != 0)
	{
		dig = num % 10;
		sum = sum + dig;
		num = num / 10;
	}

	return sum;
}