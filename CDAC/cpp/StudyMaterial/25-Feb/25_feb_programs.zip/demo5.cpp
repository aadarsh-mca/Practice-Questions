//write a program to accept a numer in main and a function to check whether
//it is palindrome. display the result in main

#include<iostream>
using namespace std;

bool check(int);
int main()
{
	int num;
	bool flag;
	cout << "\n Enter the num:";
	cin >> num;
	flag = check(num);
	(flag == true) ? cout << "\n palindrome" :cout << "not palindrome";
	return 0;
}

bool check(int num)
{
	int revnum = 0, dig, numcopy;
	numcopy = num;
	while (numcopy != 0)
	{
		dig = numcopy % 10;
		revnum = (revnum * 10) + dig;
		numcopy = numcopy / 10;
	}
	if (revnum==num)
	{
		return true;
	}
	else
	{
		return false;
	}
}