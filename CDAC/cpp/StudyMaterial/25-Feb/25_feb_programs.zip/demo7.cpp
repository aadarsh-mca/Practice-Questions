//accept an array of 5 int and display

#include<iostream>
using namespace std;

int main()
{
	
	int size,*arr;

	cout << "\n Enter teh size:";
	cin >> size;   

	arr = new int[size];

	for (int i = 0; i < size; i++)
	{
		cout << "\n ENter the ele:";
		cin >> arr[i]; // task- try using pointer notation
	}
	for (int i = 0; i < size; i++)
	{
		cout << arr[i] << endl;
	}

	delete[] arr;

	return 0;
}