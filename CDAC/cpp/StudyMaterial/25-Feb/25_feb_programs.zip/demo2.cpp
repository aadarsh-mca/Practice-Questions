//write a program to accept 2 nos and display add

#include<iostream>
using namespace std;

int main()
{
	int n1, n2, result;

	cout << "\n Enter the 2 nos:";
	/*cin >> n1;
	cin >> n2;*/
	cin >> n1 >> n2;
	result = n1 + n2;
	cout << "\n the result of "<<n1<<" and "<<n2<<" sum  is " << result;
	return 0;
}
