#pragma once
#include"Book.h"

class PrintToScreen
{
public:
	static void acceptBooks(Book* barr, int size)
	{
		for (int i = 0; i < size; i++)
		{
			barr[i].accept();
		}
	}
	static void dispplayAllBooks(Book *barr,int size)
	{
		cout << "\n All books list----------";
		for (int i = 0; i < size; i++)
		{
			barr[i].display();
		}
	}
	static void searchByCategory(Book* barr, int size)
	{
		cout << "\n enter the category to search----";
		string cat;
		cin >> cat;
		for (int i = 0; i < size; i++)
		{
			if (barr[i].getCategory() == cat)
			{
				barr[i].display();
			}
		}
	}
};
