#pragma once
#include<iostream>
using namespace std;
class Book
{
private:
	string isbn;
	string name;
	string author;
	string category;
	float price;
	static string lib_name;
public:
	Book();
	Book(string isbn, string name, string author, string category, float price);
	void display() const;
	void accept();
	string getCategory() const;
	string getAuthor() const;
};
