#include"Book.h"


string Book::lib_name = "ABC Library";

Book::Book()
{
	isbn = "NA";
	name = "NA";
	category = "NA";
	author = "NA";
	price = 0.0f;
}
Book::Book(string isbn, string name, string author, string category, float price)
{
	this->isbn = isbn;
	this->name = name;
	this->author = author;
	this->category = category;
	this->price = price;
}
void Book::display() const
{
	cout << "\n the book details are:-------";
	cout << isbn << endl;
	cout << name << endl;
	cout << author << endl;
	cout << price << endl;
}
string Book::getCategory() const
{
	return category;
}

string Book::getAuthor() const
{
	return author;
}
void Book::accept()
{
	cout << "\n enter the details of the book:";
	cin >> isbn >> name >> author >> category >> price;

}