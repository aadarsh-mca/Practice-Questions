#include"Book.h"
#include"PrintToScreen.h"
int main()
{
	int size;
	cout << "\n enter the number of books:";
	cin >> size;   //3
	Book* barr = new Book[size];
	PrintToScreen::acceptBooks(barr, size);
	cout << "\n 1. Display All books \n 2. Search By Category";
	cout << "\n enter the choice:";
	int choice;
	cin >> choice;
	switch (choice)
	{
	case 1: 
		PrintToScreen::dispplayAllBooks(barr, size);
		break;

	case 2:
		PrintToScreen::searchByCategory(barr, size);
		break;
	default:
		cout << "\n invalid choice";
		break;
	}
	delete[] barr;	

}