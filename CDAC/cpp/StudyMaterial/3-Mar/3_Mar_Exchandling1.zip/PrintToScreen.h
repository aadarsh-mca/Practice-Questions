#pragma once

#include<iostream>
using namespace std;

class PrintToScreen
{
public:
	static int divide(int numerator, int denominator)
	{
		if (denominator == 0)
		{
			throw 0;
		}
		if (denominator < 0)
		{
			string err = "Cant divide by negative number";
			throw err;
		}
		int result = numerator / denominator;
		return result;
	}
};
