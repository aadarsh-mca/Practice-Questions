#include<iostream>
using namespace std;
#include"PrintToScreen.h"
int main()
{
	int numerator, denominator, result;

	cout << "\n enter  the numerator:";
	cin >> numerator;
	cout << "\n enter  the denominator:";
	cin >> denominator;
	try
	{
		result =PrintToScreen::divide(numerator, denominator);
		cout << "\n the result is " << result;
	}
	catch (int ex)
	{
		cout << "\n division by "<<ex<<" not allowed";
	}
	catch (string ex)
	{
		cout << ex;
	}
	return 0;
}
