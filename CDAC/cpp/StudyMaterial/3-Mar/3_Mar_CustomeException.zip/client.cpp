#include"Student.h"
#include"StudentException.h"
int main()
{
	try
	{
		Student s1(1, "Max", 120);
		s1.display();
	}
	catch (Studentexception ex)
	{
		cout << ex.what();
	}
}