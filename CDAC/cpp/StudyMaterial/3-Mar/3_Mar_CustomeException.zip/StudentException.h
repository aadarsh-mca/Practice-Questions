#pragma once
#include<iostream>
using namespace std;
#include<string.h>

class Studentexception:exception
{
private:
	char errMsg[50];
public:
	Studentexception(const char errMsg[50])
	{
		strcpy(this->errMsg , errMsg);
	}
	char const* what() const
	{
		return this->errMsg;
	}


};
