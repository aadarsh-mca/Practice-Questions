#include"Student.h"
#include"StudentException.h"
Student::Student(int id, string name, float marks)
{
	if (id < 0)
	{
		//throw new Studentexception("ID cant be negative");
		Studentexception ex("ID cannot be negative");
		throw ex;
		//throw an object of  custome exception class
	}
	if (marks > 100 || marks < 1)
	{
		Studentexception ex("Marks are invalid");
		throw ex;
		//throw an object of  custome exception class
	}
	this->id = id;
	this->name = name;
	this->marks = marks;
}

void Student::display()
{
	cout << "\n the details are------------"<<endl;
	cout << id << endl;
	cout << name << endl;
	cout << marks << endl;
}