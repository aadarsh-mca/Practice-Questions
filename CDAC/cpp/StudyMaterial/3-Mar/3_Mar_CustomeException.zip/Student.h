#pragma once

#include<iostream>
using namespace std;

class Student
{
private:
	int id;
	string name;
	float marks;
public:
	Student(int id, string name, float marks);
	void display();
};
