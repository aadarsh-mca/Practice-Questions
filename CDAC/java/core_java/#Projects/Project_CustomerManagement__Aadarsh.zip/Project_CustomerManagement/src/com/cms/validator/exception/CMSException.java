package com.cms.validator.exception;

@SuppressWarnings("serial")
public class CMSException extends Exception {
	
	public CMSException(String msg) {
		super(msg);
	}

}
