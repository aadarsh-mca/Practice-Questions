package com.cms.validator.exception;

public class ErrorConstant {
	public static final String PLAN_RATE_ERROR_MSG = "\nService Plan you are trying to opt is not available at the given Registration Amount !!!";
}