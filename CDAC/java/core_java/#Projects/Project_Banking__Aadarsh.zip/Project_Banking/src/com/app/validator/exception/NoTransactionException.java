package com.app.validator.exception;

public class NoTransactionException extends Exception {

	public NoTransactionException(String msg) {
		super(msg);
	}
	
}
