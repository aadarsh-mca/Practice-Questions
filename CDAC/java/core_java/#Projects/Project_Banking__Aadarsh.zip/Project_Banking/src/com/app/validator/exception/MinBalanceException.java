package com.app.validator.exception;

public class MinBalanceException extends Exception {
	
	public MinBalanceException(String msg) {
		super(msg);
	}

}
