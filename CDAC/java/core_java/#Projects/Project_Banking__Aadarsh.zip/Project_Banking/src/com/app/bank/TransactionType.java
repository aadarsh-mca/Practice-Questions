package com.app.bank;

public enum TransactionType {
	CREDIT,
	DEBIT
}
