package com.app.validator.exception;

public class DuplicateAccountException extends Exception {

	public DuplicateAccountException(String msg) {
		super(msg);
	}
	
}
