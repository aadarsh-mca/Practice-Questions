package com.app.validator.exception;

public class TransferAbortedException extends Exception {

	public TransferAbortedException(String msg) {
		super(msg);
	}
	
}
