package com.app.validator.exception;

public class UnableToOpenNewAccountException extends Exception {

	public UnableToOpenNewAccountException(String msg) {
		super(msg);
	}
	
}
