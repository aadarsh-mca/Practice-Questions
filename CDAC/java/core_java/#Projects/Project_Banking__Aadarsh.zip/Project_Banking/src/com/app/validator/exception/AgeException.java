package com.app.validator.exception;

public class AgeException extends Exception {
	
	public AgeException(String msg) {
		super(msg);
	}
	
}
