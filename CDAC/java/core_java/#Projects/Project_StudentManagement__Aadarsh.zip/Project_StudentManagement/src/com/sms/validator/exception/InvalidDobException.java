package com.sms.validator.exception;

public class InvalidDobException extends Exception {
	
	public InvalidDobException(String msg) {
		super(msg);
	}

}