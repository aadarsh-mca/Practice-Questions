package com.sms.validator.exception;

public class LoginFailedException extends Exception {

	public LoginFailedException(String msg) {
		super(msg);
	}
	
}
