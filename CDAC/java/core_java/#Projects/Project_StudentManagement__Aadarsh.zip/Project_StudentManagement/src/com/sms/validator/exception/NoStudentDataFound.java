package com.sms.validator.exception;

public class NoStudentDataFound extends RuntimeException {

	public NoStudentDataFound(String msg) {
		super(msg);
	}
}
