package com.sms.validator.exception;

public class InvalidPasswordException extends Exception {

	public InvalidPasswordException(String msg) {
		super(msg);
	}
	
}
