package com.sms.validator.exception;

public class NoCourseAvailableException extends Exception {
	
	public NoCourseAvailableException(String msg) {
		super(msg);
	}

}