//package com.sms.database.service;
//
//import com.sms.core.Student;
//
//public interface StudentDataService {
//	boolean addNewStudent(Student newStudent);
//}