package com.app.bank.core;

public enum AccountType {
	Saving,
	Current,
}
