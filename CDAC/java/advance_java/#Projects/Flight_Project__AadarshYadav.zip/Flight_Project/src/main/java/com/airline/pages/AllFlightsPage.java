//package com.airline.pages;
//
//import java.io.IOException;
//import java.sql.SQLException;
//import java.util.List;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import com.airline.dao.FlightDaoImpl;
//import com.airline.pojos.Flight;
//import com.airline.utils.DBUtils;
//
//@WebServlet("/all-flights")
//public class AllFlightsPage extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//	private FlightDaoImpl flightDaoImpl;
//	
//	@Override
//	public void init() throws ServletException {
//		System.out.println("====== [ All-Flight init() ] ======");
//		try {
//			flightDaoImpl = FlightDaoImpl.getInstance();
//		} catch (Exception e) {
//			throw new ServletException(e.getMessage(), e);
//		}
//	}
//
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setContentType("text/html");
//		
//		try {
//			List<Flight> allFlights =  flightDaoImpl.getAllFlights();
//			
//			request.getSession().setAttribute("all-flights", allFlights);
//			response.sendRedirect("flight-result");
//		} catch (Exception e) {
//			throw new ServletException(e.getMessage(), e);
//		}
//	}
//
//}
