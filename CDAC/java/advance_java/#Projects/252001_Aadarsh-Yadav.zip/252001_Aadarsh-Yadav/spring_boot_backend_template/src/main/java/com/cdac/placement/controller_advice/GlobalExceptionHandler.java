package com.cdac.placement.controller_advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cdac.placement.dto.GenericResponse;
import com.cdac.placement.exception.DuplicateResourceFoundException;
import com.cdac.placement.exception.InvalidDataException;
import com.cdac.placement.exception.ResourceNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(exception = ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException error) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new GenericResponse(error.getMessage()));
	}
	
	@ExceptionHandler(exception = DuplicateResourceFoundException.class)
	public ResponseEntity<?> handleDuplicateResourceFoundException(DuplicateResourceFoundException error) {
		return ResponseEntity.badRequest()
				.body(new GenericResponse(error.getMessage()));
	}
	
	@ExceptionHandler(exception = InvalidDataException.class)
	public ResponseEntity<?> handleInvalidDataException(InvalidDataException error) {
		return ResponseEntity.badRequest()
				.body(new GenericResponse(error.getMessage()));
	}
	
//	@ExceptionHandler(exception = NullPointerException.class)
//	public ResponseEntity<?> handleNullPointerException(NullPointerException error) {
//		return ResponseEntity.badRequest()
//				.body(new GenericResponse(error.getMessage()));
//	}

}
