package com.cdac.placement.dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class GenericResponse {

	private LocalDateTime timestamp;
	
	private String message;

	public GenericResponse(String message) {
		this.timestamp = LocalDateTime.now();
		this.message = message;
	}
	
	
	
}
