package com.cdac.placement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.placement.dto.CreateJobDTO;
import com.cdac.placement.service.JobService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/jobs")
public class JobController {
	
	private final JobService jobService;
	
	@Autowired
	public JobController(JobService jobService) {
		this.jobService = jobService;
	}


	/**
	 * Adding a new job
	 * 
	 * URL - http://host:port/jobs
	 * Method - POST
	 * Payload - {
	 * 
	 * }
	 */
	@PostMapping
	public ResponseEntity<?> addNewJob(@Valid @RequestBody CreateJobDTO jobDTO) {
		return ResponseEntity.status(HttpStatus.CREATED).body(jobService.addNewJob(jobDTO));
	}
	
	/**
	 * Update existing a job
	 * 
	 * URL - http://host:port/jobs/{jobId}
	 * Method - PUT
	 * Payload - {
	 * 
	 * }
	 */
	@PutMapping("/{jobId}")
	public ResponseEntity<?> updateJobById(@PathVariable Long jobId, @Valid @RequestBody @NotNull CreateJobDTO jobDTO) {
		return ResponseEntity.ok(jobService.updateJobById(jobId, jobDTO));
	}

	/**
	 * Delete existing a job by category
	 * 
	 * URL - http://host:port/jobs/{jobCategory}
	 * Method - PUT
	 * Payload - {
	 * 
	 * }
	 */
	@DeleteMapping("/{jobCategory}")
	public ResponseEntity<?> deleteJobByCategory(@PathVariable String jobCategory) {
		return ResponseEntity.ok(jobService.deleteJobById(jobCategory));
	}

	/**
	 * Get all job
	 * 
	 * URL - http://host:port/jobs
	 * Method - GET
	 * Payload - {}
	 */
	@GetMapping
	public ResponseEntity<?> getAllJob() {
		return ResponseEntity.ok(jobService.getAllJob());
	}
	
	/**
	 * Get all job by salary
	 * 
	 * URL - http://host:port/jobs/salary/{salary}
	 * Method - GET
	 * Payload - {}
	 */
	@GetMapping("/salary/{salary}")
	public ResponseEntity<?> getAllJobBySalary(@PathVariable Long salary) {
		return ResponseEntity.ok(jobService.getAllJob(salary));
	}
	
	/**
	 * Get all job by location
	 * 
	 * URL - http://host:port/jobs/location/{location}
	 * Method - GET
	 * Payload - {}
	 */
	@GetMapping("/location/{location}")
	public ResponseEntity<?> getAllJobByLocation(@PathVariable String location) {
		return ResponseEntity.ok(jobService.getAllJob(location));
	}
	
	
	
	
	
	
	
	
}
