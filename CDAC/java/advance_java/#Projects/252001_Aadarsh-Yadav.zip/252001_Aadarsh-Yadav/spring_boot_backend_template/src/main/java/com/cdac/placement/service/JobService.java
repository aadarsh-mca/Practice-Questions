package com.cdac.placement.service;

import java.util.List;

import com.cdac.placement.dto.CreateJobDTO;
import com.cdac.placement.enums.JobCategory;

public interface JobService {
	
	CreateJobDTO addNewJob(CreateJobDTO jobDTO);
	
	CreateJobDTO updateJobById(Long jobId, CreateJobDTO jobDTO);

	List<CreateJobDTO> deleteJobById(String category);
	
	List<CreateJobDTO> getAllJob();

	List<CreateJobDTO> getAllJob(Long salary);
	
	List<CreateJobDTO> getAllJob(String location);
}
