package com.cdac.placement.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateJobDTO {

	@JsonProperty(access = Access.READ_ONLY)
	private Long id;
	
	@JsonProperty(access = Access.READ_ONLY)
	private LocalDateTime updatedOn;
	
	@NotBlank(groups = String.class,  message = "Job title cannot be blank !!!")
	private String title;
	
	private String category;
	
	private String description;
	
	private Long salary;

	private String location;

	private List<String> skillRequired = new ArrayList<>();
	
	private LocalDate postDate;

	public void setCategory(String category) {
		this.category = category.toUpperCase();
	}
	
}
