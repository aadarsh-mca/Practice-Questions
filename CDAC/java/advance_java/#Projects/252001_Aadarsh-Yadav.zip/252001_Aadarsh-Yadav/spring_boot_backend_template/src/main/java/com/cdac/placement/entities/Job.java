package com.cdac.placement.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import com.cdac.placement.enums.JobCategory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "jobs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Job extends BaseEntity {
	
	@Column(length = 50, nullable = false)
	private String title;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private JobCategory category;
	
	@Column(length = 200, nullable = false)
	private String description;
	
	@Column(nullable = false)
	private Long salary;

	@Column(length = 30, nullable = false)
	private String location;
	
//	@Column(name = "skill_req")
	private List<String> skillRequired = new ArrayList<>();
	
	@Column(name = "post_date", nullable = false)
	private LocalDate postDate;
}
