package com.cdac.placement.enums;

public enum JobCategory {

	HEALTHCARE,
	EDUCATIONAL,
	TECHNOLOGY,
	ENGINEERING
	
}
