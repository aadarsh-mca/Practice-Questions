package com.cdac.placement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.placement.entities.Job;
import com.cdac.placement.enums.JobCategory;

public interface JobRepository extends JpaRepository<Job, Long> {
	
	List<Job> findAllByCategory(JobCategory category);
	
	List<Job> findAllBySalary(Long salary);
	
	List<Job> findAllByLocation(String location);

}
