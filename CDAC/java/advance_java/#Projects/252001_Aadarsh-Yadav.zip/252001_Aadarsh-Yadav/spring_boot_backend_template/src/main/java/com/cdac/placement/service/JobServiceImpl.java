package com.cdac.placement.service;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cdac.placement.dto.CreateJobDTO;
import com.cdac.placement.entities.Job;
import com.cdac.placement.enums.JobCategory;
import com.cdac.placement.exception.InvalidDataException;
import com.cdac.placement.exception.ResourceNotFoundException;
import com.cdac.placement.repository.JobRepository;

@Service
@Transactional
public class JobServiceImpl implements JobService {
	
	private JobRepository jobRepository;
	private ModelMapper modelMapper;
	
	@Autowired
	public JobServiceImpl(JobRepository jobRepository, ModelMapper modelMapper) {
		this.jobRepository = jobRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public CreateJobDTO addNewJob(CreateJobDTO jobDTO) {
		if(jobDTO.getTitle().isBlank()) {
			throw new InvalidDataException("Job Title cannot be empty !!!");
		}
		if(jobDTO.getPostDate().isEqual(LocalDate.now()) == false) {
			throw new InvalidDataException("Post Date '" + jobDTO.getPostDate() + "' is either before or after the Current Date. It must be today's date !!!");
		}
		
		Job job = modelMapper.map(jobDTO, Job.class);
		
		return modelMapper.map(jobRepository.save(job), CreateJobDTO.class);
	}

	@Override
	public CreateJobDTO updateJobById(Long jobId, CreateJobDTO jobDTO) {
		Job job = jobRepository.findById(jobId)
				.orElseThrow(() -> new ResourceNotFoundException("No Job found with the given ID " + jobId));
		
		jobDTO.setId(jobId);
		Job updateJob = jobRepository.save(modelMapper.map(jobDTO, Job.class));
		jobRepository.flush();
		
		return modelMapper.map(updateJob, CreateJobDTO.class);
	}

	@Override
	public List<CreateJobDTO> deleteJobById(String category) {
		List<Job> jobsByCategory = jobRepository.findAllByCategory(JobCategory.valueOf(category.toUpperCase()));
		
		if(jobsByCategory.isEmpty()) {
			throw new ResourceNotFoundException("No Job found with the given Category " + category);
		}
		
		jobsByCategory.forEach(job -> jobRepository.delete(modelMapper.map(job, Job.class)));
		
		return jobsByCategory.stream()
				.map(job -> modelMapper.map(job, CreateJobDTO.class))
				.toList();
	}

	@Override
	public List<CreateJobDTO> getAllJob() {
		List<Job> allJobs = jobRepository.findAll();
		
		if(allJobs.isEmpty()) {
			throw new ResourceNotFoundException("No Job found !!!");
		}
		
		return allJobs.stream()
				.map(job -> modelMapper.map(job, CreateJobDTO.class))
				.toList();
	}

	@Override
	public List<CreateJobDTO> getAllJob(Long salary) {
		List<Job> jobsBySalary = jobRepository.findAllBySalary(salary);
		
		if(jobsBySalary.isEmpty()) {
			throw new ResourceNotFoundException("No Job found with the given Salary " + salary);
		}
		
		return jobsBySalary.stream()
				.map(job -> modelMapper.map(job, CreateJobDTO.class))
				.toList();
	}

	@Override
	public List<CreateJobDTO> getAllJob(String location) {
		List<Job> jobsByLocation = jobRepository.findAllByLocation(location);
		
		if(jobsByLocation.isEmpty()) {
			throw new ResourceNotFoundException("No Job found with the given Location " + location);
		}
		
		return jobsByLocation.stream()
				.map(job -> modelMapper.map(job, CreateJobDTO.class))
				.toList();
	}

}
