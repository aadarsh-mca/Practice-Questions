package com.cdac.vehicle.enums;

public enum Brand {
	HERO,
	BAJAJ,
	TVS,
	KAWASAKI,
	SUZUKI
}
