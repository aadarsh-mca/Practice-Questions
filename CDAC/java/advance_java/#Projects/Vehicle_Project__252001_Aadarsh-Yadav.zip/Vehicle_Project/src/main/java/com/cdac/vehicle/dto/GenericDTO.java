package com.cdac.vehicle.dto;

public interface GenericDTO {
}
