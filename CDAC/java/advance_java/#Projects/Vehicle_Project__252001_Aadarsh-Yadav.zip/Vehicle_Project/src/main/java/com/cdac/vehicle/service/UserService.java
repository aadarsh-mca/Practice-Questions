package com.cdac.vehicle.service;

import com.cdac.vehicle.dto.GenericResponseWithDTO;
import com.cdac.vehicle.dto.CreateUserDTO;
import com.cdac.vehicle.dto.ShowUserDTO;

import java.util.List;

public interface UserService {

    List<ShowUserDTO> getAllUsers();

    CreateUserDTO getUserById(Long userId);

    CreateUserDTO createNewUser(CreateUserDTO userDTO);

//    List<ShowVehicleDTO> getUserByNameWithAllVehicles(String username);

    GenericResponseWithDTO deleteAllVehicleFromUserByName(String username);

}
