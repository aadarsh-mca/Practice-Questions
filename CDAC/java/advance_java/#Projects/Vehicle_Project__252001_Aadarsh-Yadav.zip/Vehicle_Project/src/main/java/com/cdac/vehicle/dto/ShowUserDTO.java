package com.cdac.vehicle.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class ShowUserDTO {
    private Long id;

    private String name;

    private LocalDate dob;

    private String email;

    private String contactNo;

    private String city;
}
